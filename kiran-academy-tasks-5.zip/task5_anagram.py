# Task 5: Check whether Word1 and Word2 are Anagrams
word1 = input("Enter Word1: ").replace(" ", "").lower()
word2 = input("Enter Word2: ").replace(" ", "").lower()

if sorted(word1) == sorted(word2):
    print("The words are Anagrams")
else:
    print("The words are not Anagrams")
