# Task 1: Hello World
YOUR_NAME = "Namrata"
print("Hello World")
print("My name is", YOUR_NAME)
