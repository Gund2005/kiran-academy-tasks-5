# Kiran Academy - 5 Basic Programming Tasks

1. Hello World
2. Cost Price & Selling Price - Profit/Loss
3. Odd or Even Number
4. Valid Age & Voting Eligibility
5. Anagram Check
