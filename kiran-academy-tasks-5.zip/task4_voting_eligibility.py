# Task 4: Valid Age and Voting Eligibility
age = int(input("Enter your age: "))

if age < 0:
    print("Invalid age")
elif age >= 18:
    print("Valid age - Eligible for voting")
else:
    print("Valid age - Not eligible for voting")
